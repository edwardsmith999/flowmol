cd /mnt/qnap3/Bypass_DNS_Data/Data/ZPG_DATA2
% cd to grid file dir
cd Run_Prmtrs_Grid/
read_grid
ngz = ngy;
nsz = nsy;

% cd to subdom dir
cd ../Data_TimeSeq/
files = dir('Sub*');

% remove restart subdoms
dt = 40;
filenames = filenames_const_dt(files,dt);

skipk = 2;
skipi = 2;
skipj = 2;

pz = 1:nsz;
px = 1:nsx;
py = 1:nsy;

% read subdoms one at a time
for n = 1%:length(filenames)
V{n} = read_sub(filenames(n).name,ngz,ngx,ngy,pz,px,py,skipk,skipi,skipj,3);
end